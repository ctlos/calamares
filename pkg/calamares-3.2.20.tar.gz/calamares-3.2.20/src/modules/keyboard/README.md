Keyboard layout configuration viewmodule
---
Requires ckbcomp script.
 * Debian package console-setup or
 * Manjaro package keyboardctl https://github.com/manjaro/packages-core/tree/master/keyboardctl
