This has moved [to the wiki](https://github.com/calamares/calamares/wiki/Develop-Code).
